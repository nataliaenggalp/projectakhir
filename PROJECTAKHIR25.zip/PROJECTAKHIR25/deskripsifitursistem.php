<html>
<head>
	<title>Lowongan Kerja</title>
	
</head>
<body>
<div id="deskripsi">
<a href="index.php">kembali ke halaman awal</a>

<h2>Deskrpisi Fitur Sistem</h2>
<p>Kemampuan Akses Umum :</p>
<p>-Beranda</p>
<p>---Identitas Mahasiswa / Pembangun Website</p>
<p>-Lowongan</p>
<p>---Daftar lowongan kerja</p>
<p>---DetailLowongan Kerja</p>
<p>-Daftar sebagai member</p>
<p>---Daftar pendaftaran sebagai member perusahaan</p>
<p>---Daftar pendaftaran sebagai member calon pekerja</p>
<p>-Masuk sebagai member</p>
<p>---Masuk sebagai member perusahaan</p>
<p>---Masuk sebagai member colon pekerja</p>
<p>---Masuk sebagai admin</p>
<p>-Tantang Kami</p>
<p>---Deskripsi kemapuan website</p>
<p>-Kontak</p>
<p>---Info Kontak</p>

<p>Kemampuan Akses Member Perusahaan:</p>
<p>-Beranda</p>
<p>---Identitas Mahasiswa / Pembangun Website</p>
<p>-Lowongan</p>
<p>---Daftar lowongan kerja</p>
<p>---DetailLowongan Kerja</p>
<p>-----Komen Lowongan Pekerjaan</p>
<p>-Daftar sebagai member</p>
<p>---Daftar pendaftaran sebagai member perusahaan</p>
<p>---Daftar pendaftaran sebagai member calon pekerja</p>
<p>-Masuk sebagai member</p>
<p>---Masuk sebagai member perusahaan</p>
<p>---Masuk sebagai member colon pekerja</p>
<p>---Masuk sebagai admin</p>
<p>-Keluar sebagai member perusahaan</p>
<p>-Tantang Kami</p>
<p>---Deskripsi kemapuan website</p>
<p>-Kontak</p>
<p>---Info Kontak</p>
<p>-Menu Perushaan</p>
<p>---Tambah lowongan kerja</p>
<p>---Edit Lowongan kerja</p>
<p>---Hapus Lowongan kerja</p>
<p>---Edit Profil Perusahaan</p>
<p>-Daftar Pengisi Lowongan Kerja Di Perusahaan Itu Sendiri</p>
<p>---Daftar Lowongan Kerja Yang Di Cantumkan Oleh Perusahaan Itu Sendiri</p>
<p>---Lihat Profil Calon Pekerja Yang Mendaftar</p>
<p>---Unduk Dokumen Pekerja yang melamar</p>
<p>---Lihat Lamaran Calon Pekerja Yang Mendaftar</p>
<p>---Kirim Email Calon Pekerja Terpilih</p>
<p>---Kirim Email Calon Pekerja Tidak Terpilih</p>

<p>Kemampuan Akses Member Calon Pekerja :</p>
<p>-Beranda</p>
<p>---Identitas Mahasiswa / Pembangun Website</p>
<p>-Lowongan</p>
<p>---Daftar lowongan kerja</p>
<p>--->Detail Lowongan Kerja</p>
<p>----->Komen Lowongan Pekerjaan</p>
<p>----->Lamar Lowongan Pekerjaan</p>
<p>-------->Input Biodata Calon Pekerja</p>
<p>-------->Input File Dokumen Lamaran</p>
<p>-Daftar sebagai member</p>
<p>---Daftar pendaftaran sebagai member perusahaan</p>
<p>---Daftar pendaftaran sebagai member calon pekerja</p>
<p>-Masuk sebagai member</p>
<p>---Masuk sebagai member perusahaan</p>
<p>--->Masuk sebagai member colon pekerja</p>
<p>---Masuk sebagai admin</p>
<p>-Keluar sebagai member calon pekerja</p>
<p>-Tantang Kami</>
<p>---Deskripsi kemapuan website</p>
<p>-Kontak</p>
<p>---Info Kontak</p>
<P>-Menu Calon Pekerja</p>
<p>--->daftar lowongan kerja yang telah dilamar</p>

<p>Kemampuan Akses Admin :</p>
<p>-Beranda</p>
<p>---Identitas Mahasiswa / Pembangun Website</p>
<p>-Lowongan</p>
<p>---Daftar lowongan kerja</p>
<p>---DetailLowongan Kerja<p>
<p>-Daftar sebagai member</p>
<p>---Daftar pendaftaran sebagai member perusahaan</p>
<p>---Daftar pendaftaran sebagai member calon pekerja</p>
<p>-Masuk sebagai member</p>
<p>---Masuk sebagai member perusahaan</p>
<p>---Masuk sebagai member colon pekerja</p>
<p>---Masuk sebagai admin</p>
<p>-Keluar sebagai admin</p>
<p>-Tantang Kami</p>
<p>---Deskripsi kemapuan website</p>
<p>-Kontak</p>
<p>---Info Kontak</p>
<p>-Menu Admin</p>
<p>---Isi Deskripsi Beranda</p>
<p>---Isi Info Tentang Kami</P>
<p>---Isi Info Kontak</p>
<p>---Lihat, Ubah, Hapus, database calon pekerja</p>
<p>---Lihat, Ubah, Hapus, database perusahaan</p>
<p>---Lihat, Ubah, Hapus, database lowongan</p>
<p>---Lihat, Ubah, Hapus, database lamaran pekerjaan</p>
				
			</div>
			
		</div>
		
	</div>
</body>
</html>